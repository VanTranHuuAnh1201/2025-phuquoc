# Tài Liệu Kỹ Thuật, Schema SQL & Danh Sách Ticket Triển Khai (Dev Roadmap)

> **Dự án**: Hệ thống Website Đặt Phòng & Web CMS Quản Lý Resort (The Nam Du Hill Resort)  
> **Cấu trúc Monorepo**: `apps/2026-thenamduhill`, `@repo/core`, `@repo/ui`  
> **Áp dụng cho**: Đội ngũ Lập trình viên (Frontend Dev, Backend Dev, DB Eng), Tech Lead & QA / Tester  
> **Ánh xạ 1:1 với Bản PM**: Mô tả CSDL SQL Schema (bổ sung trường `booking_source`, `child_ages`, `min_nights_holiday`, phân quyền 3 cấp SuperAdmin/Admin/User, Auth Token/Refresh Token), phân rã Ticket với ETA FE/BE/Hoàn thành và DoD chi tiết.

---

# PHẦN 1: TỔNG QUAN QUALITY GATE & KIẾN TRÚC CƠ SỞ DỮ LIỆU SQL (DATABASE SCHEMA)

## 1.1 Bảng Quy Chuẩn Quality Gate Dành Cho Dev Team

| # | Tiêu chuẩn | Mô tả chi tiết Quality Gate | Điều kiện nghiệm thu (DoD) |
|---|---|---|---|
| **1.1.1** | **Code Quality & Type Safety** | Mọi file TypeScript trong `apps/2026-thenamduhill` và `@repo/*`. | Pass 100% `pnpm typecheck`, 0 warning, 0 type `any`. Tách biệt logic `@repo/core` và theme `@repo/theme-h3`. |
| **1.1.2** | **Database (Supabase PostgreSQL)** | Thiết kế Schema chuẩn Relational DB. | 100% bảng có Primary Key, Timestamp (`created_at`, `updated_at`), RLS policy cho Admin/Public và file Migration `.sql`. |
| **1.1.3** | **API & Realtime Sync** | Route Handlers Node.js/Next.js. | Trả về JSON chuẩn `{ success, data, error }`. Thao tác CRUD từ CMS phản ánh realtime lên Client/Lookup. |

---

## 1.2 Chi Tiết Các Bảng Dữ Liệu SQL (Supabase PostgreSQL Data Tables)

```sql
-- 1. BẢNG NGUỜI DÙNG QUẢN TRỊ & PHÂN QUYỀN (users)
CREATE TABLE public.users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    role VARCHAR(20) DEFAULT 'USER' NOT NULL, -- SUPERADMIN, ADMIN, USER
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    refresh_token TEXT, -- Token gia hạn phiên đăng nhập
    refresh_token_expires_at TIMESTAMPTZ,
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT chk_user_role CHECK (role IN ('SUPERADMIN', 'ADMIN', 'USER'))
);

-- 2. BẢNG LOẠI PHÒNG (room_types)
CREATE TABLE public.room_types (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    base_price_weekday DECIMAL(12, 2) NOT NULL, -- Giá ngày thường
    base_price_weekend DECIMAL(12, 2) NOT NULL, -- Giá T6-T7 cuối tuần
    base_price_holiday DECIMAL(12, 2) NOT NULL, -- Giá ngày Lễ/Tết
    min_nights_holiday INT DEFAULT 2 NOT NULL, -- Số đêm ở tối thiểu ngày Lễ (P-07)
    max_adults INT DEFAULT 2 NOT NULL,
    max_children INT DEFAULT 2 NOT NULL,
    description TEXT,
    images JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. BẢNG PHÒNG VẬT LÝ (rooms)
CREATE TABLE public.rooms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_number VARCHAR(50) UNIQUE NOT NULL, -- Ví dụ: P.101, Villa 02
    room_type_id UUID REFERENCES public.room_types(id) ON DELETE CASCADE,
    status VARCHAR(50) DEFAULT 'CLEAN' NOT NULL, -- CLEAN, DIRTY, MAINTENANCE
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. BẢNG ĐƠN ĐẶT PHÒNG (bookings)
CREATE TABLE public.bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_code VARCHAR(50) UNIQUE NOT NULL, -- NDH-YYYYMMDD-XXXX (Thống nhất 1 format)
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(50) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    customer_id_card VARCHAR(50), -- Số CCCD/Passport
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    room_type_id UUID REFERENCES public.room_types(id),
    assigned_room_id UUID REFERENCES public.rooms(id), -- Gán số phòng vật lý khi Lễ tân xếp
    num_adults INT DEFAULT 1 NOT NULL,
    num_children INT DEFAULT 0 NOT NULL,
    child_ages INT[] DEFAULT '{}', -- Mảng số tuổi từng trẻ em (P-02b)
    booking_source VARCHAR(50) DEFAULT 'WEB' NOT NULL, -- WEB, PHONE, WALK_IN, OTA_MANUAL (B-05)
    
    -- 3 Chỉ số tài chính bắt buộc theo Requirement P-04
    total_amount DECIMAL(12, 2) NOT NULL, -- Tổng thanh toán cuối cùng
    deposit_amount DECIMAL(12, 2) NOT NULL, -- Số tiền cần cọc (Mặc định 50%)
    remaining_amount DECIMAL(12, 2) NOT NULL, -- Số tiền còn lại thu tại quầy
    
    discount_amount DECIMAL(12, 2) DEFAULT 0.00,
    promo_code VARCHAR(50),
    
    status VARCHAR(50) DEFAULT 'PENDING' NOT NULL, 
    -- PENDING, HOLD_TEMPORARY, DEPOSITED, CONFIRMED, CHECKED_IN, CHECKED_OUT, CANCELLED, NO_SHOW, EXPIRED
    
    hold_expires_at TIMESTAMPTZ, -- Hạn giữ phòng 15 phút theo QR Timeout (B-01)
    vat_requested BOOLEAN DEFAULT FALSE,
    vat_company_name VARCHAR(255),
    vat_tax_code VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. BẢNG PHỤ THU & PHÁT SINH (booking_surcharges)
CREATE TABLE public.booking_surcharges (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID REFERENCES public.bookings(id) ON DELETE CASCADE,
    category VARCHAR(50) NOT NULL, -- EXTRA_GUEST, CHILD_AGE, LATE_CHECKOUT, MINIBAR, RESCHEDULE_FEE
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    is_manual BOOLEAN DEFAULT FALSE NOT NULL, -- TRUE nếu Lễ tân nhập thủ công trên CMS
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. BẢNG MÃ GIẢM GIÁ (promo_codes)
CREATE TABLE public.promo_codes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) UNIQUE NOT NULL,
    discount_type VARCHAR(20) NOT NULL, -- PERCENTAGE, FIXED_AMOUNT
    discount_value DECIMAL(12, 2) NOT NULL,
    valid_from DATE NOT NULL,
    valid_to DATE NOT NULL,
    max_uses INT DEFAULT 100,
    used_count INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. BẢNG LỊCH SỬ GIAO DỊCH THANH TOÁN (payment_transactions)
CREATE TABLE public.payment_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID REFERENCES public.bookings(id) ON DELETE CASCADE,
    transaction_reference VARCHAR(100) NOT NULL, -- Mã giao dịch ngân hàng
    payment_method VARCHAR(50) NOT NULL, -- VIETQR, VISA, CASH
    amount DECIMAL(12, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'SUCCESS' NOT NULL,
    raw_payload JSONB, -- Payload Webhook lưu đối soát
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. BẢNG LOG VẾT THAY ĐỔI & ĐỔI NGÀY (booking_audit_logs)
CREATE TABLE public.booking_audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID REFERENCES public.bookings(id) ON DELETE CASCADE,
    action VARCHAR(100) NOT NULL, -- CREATE, DEPOSIT_SUCCESS, RESCHEDULE, ROOM_CHANGE, NO_SHOW, CANCEL
    performed_by VARCHAR(100) NOT NULL, -- CLIENT, SYSTEM_CRON, ADMIN_EMAIL
    old_data JSONB,
    new_data JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

## 1.3 Cơ Chế Xác Thực & Phân Quyền Authentication (JWT Token & Refresh Token)

- **Cơ chế Token**:
  - `Access Token`: Mã JWT ngắn hạn (Thời hạn 15 phút), lưu trong Header Bearer hoặc Cookie `access_token`.
  - `Refresh Token`: Mã JWT dài hạn (Thời hạn 7 ngày), lưu trong `HTTP-Only Cookie` bảo mật (`SameSite=Strict, Secure`), ghi nhận trong cột `refresh_token` của bảng `users`.
- **Middleware Security Guard (`middleware.ts`)**:
  - Kiểm tra `role` trong Payload Token khi truy cập `/admin/*` và Route Handlers `/api/admin/*`.
  - **SuperAdmin**: Quyền xem báo cáo tổng, sửa tài khoản, đổi cấu hình Ngân hàng.
  - **Admin**: Quyền quản lý đơn, tạo đơn điện thoại (`B-05`), duyệt hủy/hoàn cọc, khóa phòng OTA.
  - **User (Lễ tân)**: Quyền gán phòng, tạo đơn điện thoại (`B-05`), check-in/out, nhập minibar/phụ thu thủ công, khóa phòng khẩn cấp di động.

---

# PHẦN 2: BẢNG DANH SÁCH TICKET TRIỂN KHAI THEO DANH MỤC CHỨC NĂNG (GD1, GD2, GD3)

## 2.1 GIAI ĐOẠN 1 (GD1): Demo Mockup UI/UX & CMS State (Hạn hoàn thành: 10/08/2026)

| Mã Ticket | Title Công Việc | Nội Dung Chi Tiết Kỹ Thuật | Ánh Xạ PM | ETA FE | ETA BE | ETA Hoàn Thành | Definition of Done (DoD) |
|---|---|---|---|---|---|---|---|
| **DEV-101** | **Luồng Đặt Phòng 5 Bước (Theme H3)** | Dựng giao diện Client Web 5 bước: (1) Chọn ngày ➔ (2) Chọn phòng ➔ (3) Info khách & nhập tuổi trẻ em (`P-02b`) ➔ (4) PTTT & Cọc 50% (`P-04`) ➔ (5) Màn thành công. | Case `P-01`, `P-02b`, `P-04` | 18 Hours | 4 Hours | **07/08/2026** | - Chạy mượt qua đúng 5 bước công khai.<br>- Cho phép chọn số lượng & điền số tuổi từng trẻ em (`P-02b`).<br>- Sinh mã đơn duy nhất format `NDH-YYYYMMDD-XXXX`.<br>- Lưu dữ liệu tạm trong Zustand store `booking.store.ts`. |
| **DEV-102** | **CMS Admin Mockup CRUD & Tạo Đơn Thủ Công** | Dựng CMS Admin Lễ tân: Quản lý đơn hàng, gán phòng vật lý (`B-03`), **Form Tạo đơn mới trực tiếp qua Điện thoại/Zalo (`B-05`)**, đổi trạng thái & nhập Phụ Thu thủ công (`P-02a`). | Case `P-02a`, `B-03`, `B-05` | 16 Hours | 4 Hours | **08/08/2026** | - CMS thao tác mượt mà không giật lag.<br>- Form Tạo đơn thủ công hỗ trợ chọn nguồn đơn (`WEB`, `PHONE`, `WALK_IN`).<br>- Modal chi tiết đơn hiển thị ô nhập/sửa Phụ Thu thủ công & Minibar. |
| **DEV-103** | **Review Demo Vercel & Chốt Scope** | Triển khai build thử bản demo Vercel, cùng PM và Khách hàng review lại toàn bộ luồng trải nghiệm. | Master Matrix | 4 Hours | 4 Hours | **10/08/2026** | - Khách hàng duyệt bản mẫu H3 và CMS Admin.<br>- Chốt sạch 16 Case Requirements (`P-01` ➔ `N-01`). |

---

## 2.2 GIAI ĐOẠN 2 (GD2): Supabase DB, Auth JWT, APIs Engine, SendGrid Email & Lookup (Hạn hoàn thành: 17/08/2026)

| Mã Ticket | Title Công Việc | Nội Dung Chi Tiết Kỹ Thuật | Ánh Xạ PM | ETA FE | ETA BE | ETA Hoàn Thành | Definition of Done (DoD) |
|---|---|---|---|---|---|---|---|
| **DEV-201** | **Supabase DB Schema & Atomic Locking** | Tải file SQL Migration (8 bảng gồm `users`, `child_ages`, `booking_source`) lên Supabase. Viết Function `create_booking_atomic()` khóa tạm phòng 15p theo Bank QR Timeout (`B-01`), lưu 3 chỉ số cọc (`P-04`) & Audit log (`P-06`). | Case `B-01`, `P-04`, `P-06` | 2 Hours | 16 Hours | **12/08/2026** | - Migration thành công Schema 8 bảng lên Supabase Cloud.<br>- Hàm `create_booking_atomic` dùng `SELECT FOR UPDATE` khóa phòng 15p theo QR Timeout.<br>- Lưu chính xác 3 chỉ số: `total_amount`, `deposit_amount`, `remaining_amount`. |
| **DEV-202** | **Pricing, Min-Nights & Reschedule API Engine** | Viết Route Handler `/api/bookings/calculate-price` tính `Total = (BaseRate - Discount) + Surcharges` (`P-03`), tính tuổi trẻ em (`P-02b`), check ràng buộc số đêm tối thiểu ngày Lễ (`P-07`), API Đổi ngày (`P-06`), Hoàn cọc (`P-05`) & **Cron Job xử lý Khách vắng mặt No-Show 18h00 (`B-04`)**. | Case `P-01`, `P-02b`, `P-03`, `P-05`, `P-06`, `P-07`, `B-04` | 6 Hours | 20 Hours | **13/08/2026** | - Tách giá từng đêm với `date-fns` per-night loop, ép múi giờ GMT+7 `Asia/Ho_Chi_Minh`.<br>- Ràng buộc chặn chọn 1 đêm nếu rơi vào dịp Lễ Tết (`P-07`).<br>- Cron Job tự động chuyển đơn thành `NO_SHOW` & nhả phòng lúc 18h00 ngày Check-in (`B-04`). |
| **DEV-203A** | **CMS Admin Realtime & Phân Quyền RBAC** | Thay nguồn Zustand bằng Supabase Realtime client. Nút 1-click đổi phòng khi check-out muộn (`B-03`), ô nhập Phụ thu thủ công (`P-02a`), Form Tạo đơn điện thoại (`B-05`). | Case `P-02a`, `B-03`, `B-05` | 10 Hours | 8 Hours | **14/08/2026** | - CMS Admin ghi nhận dữ liệu trực tiếp vào DB Supabase.<br>- Hai Lễ tân xem cùng một giao diện nhìn thấy đơn mới đồng bộ realtime.<br>- Lễ tân tự tạo đơn khách gọi điện/Zalo thành công. |
| **DEV-203B** | **Auth JWT & RBAC Middleware Guard** | Viết APIs `/api/auth/login`, `/api/auth/refresh` cấp Token & Refresh Token (HTTP-Only Cookie). Cấu hình Middleware kiểm tra quyền 3 cấp (SuperAdmin, Admin, User) (`O-01`). | Case `O-01` | 6 Hours | 14 Hours | **14/08/2026** | - Đăng nhập cấp `access_token` (15p) & `refresh_token` (7 ngày) bảo mật Cookie.<br>- Middleware chặn Lễ tân (`USER`) sửa giá phòng hay truy cập báo cáo tổng.<br>- SuperAdmin toàn quyền quản lý tài khoản admin. |
| **DEV-204** | **SendGrid Email API & Dynamic QR Engine** | Tích hợp dịch vụ SendGrid tự động gửi email xác nhận đặt phòng kèm mã QR VietQR cọc 50% (`P-04`), link `/lookup` hiển thị nút Hủy/Hoàn cọc tự động (`P-05`). | Case `P-04`, `P-05`, `N-01` | 4 Hours | 12 Hours | **15/08/2026** | - Email gửi về hòm thư chính khách hàng ngay khi đặt xong.<br>- Payload mã QR VietQR khóa cứng số tiền cọc 50% chuẩn xác.<br>- Link `/lookup` hiển thị nút Hủy kèm số tiền hoàn cọc tự tính. |
| **DEV-205** | **Trang Tra Cứu `/lookup` & Full Test GD2** | Xây dựng trang `/lookup` tra cứu qua SĐT + Mã Booking `NDH-YYYYMMDD-XXXX`, nút Hủy đơn tự tính tiền hoàn (`P-05`), nút Đổi ngày (`P-06`) & kiểm thử full luồng GD2 (với thanh toán giả lập). | Case `P-05`, `P-06` | 12 Hours | 8 Hours | **17/08/2026** | - Khách hàng tra cứu mượt mà đơn hàng realtime.<br>- Nút Hủy hiển thị đúng số tiền hoàn; Nút Đổi ngày gọi API recalculation.<br>- Pass 100% test case trên thiết bị di động thật với thanh toán giả lập. |

---

## 2.3 GIAI ĐOẠN 3 (GD3): Live Payment Webhook, Production Domain & Bàn Giao (Hạn hoàn thành: 28/08/2026)

| Mã Ticket | Title Công Việc | Nội Dung Chi Tiết Kỹ Thuật | Ánh Xạ PM | ETA FE | ETA BE | ETA Hoàn Thành | Definition of Done (DoD) |
|---|---|---|---|---|---|---|---|
| **DEV-301** | **Live Payment Webhook Integration** | Viết Route Handler `/api/webhooks/payment` nhận tin chuyển khoản VietQR/PayOS thật trong 3 giây. Xác thực chữ ký HMAC-SHA256 bảo mật (`C-01`). | Case `C-01`, `P-04` | 4 Hours | 14 Hours | **26/08/2026** | - Kích hoạt Live Payment Webhook thật trên môi trường Production.<br>- Tự động cập nhật đơn thành `DEPOSITED` trong 3 giây khi có chuyển khoản.<br>- Pass 100% kiểm tra chữ ký HMAC-SHA256 chống Giả mạo Webhook. |
| **DEV-302** | **Production Domain, SSL & DNS** | Trỏ DNS tên miền chính thức `thenamduhill.com`, cấu hình SSL HTTPS Vercel & bản ghi DKIM/SPF SendGrid. | Technical Setup | 2 Hours | 6 Hours | **27/08/2026** | - Truy cập `https://thenamduhill.com/` ổn định, SSL xanh.<br>- Nâng cấp gói Supabase Pro đảm bảo DB không bị tạm dừng. |
| **DEV-303** | **Đào Tạo Lễ Tân & Bàn Giao Hệ Thống** | Hướng dẫn Lễ tân thao tác CMS Admin: gán phòng, tạo đơn điện thoại (`B-05`), nhập phụ thu minibar (`P-02a`), đổi phòng khi check-out muộn (`B-03`), nút khóa phòng khẩn cấp OTA di động (`B-02`). | Case `B-02`, `B-03`, `B-05` | 4 Hours | 4 Hours | **28/08/2026** | - Lễ tân tự chủ vận hành 100% thao tác đón khách & khóa phòng OTA khẩn cấp.<br>- Ký biên bản nghiệm thu & bàn giao tài khoản Admin chính thức. |

---

# PHẦN 3: BẢNG TỔNG HỢP RỦI RO KỸ THUẬT & GIẢI PHÁP TRIỂN KHAI (FULL TECH RISK MATRIX)

| Mã Rủi ro | Tương ứng Case PM | Tên rủi ro nghiệp vụ | Mô tả tình huống & Hậu quả | Giải pháp xử lý Kỹ thuật (Dev) | Phương án Vận hành (Lễ tân) |
|---|---|---|---|---|---|
| **BR-01** | **B-01** | **Double Booking (Đụng trùng phòng)** | 2 khách trên 2 thiết bị bấm cọc căn phòng cuối cùng ở cùng 1 giây. | Dùng **Postgres Row-level Locking (`SELECT FOR UPDATE`)** trong `create_booking_atomic()` khóa phòng tạm 15 phút. | Khách thanh toán thành công trước giữ phòng, khách sau được hoàn cọc trong 5 phút. |
| **BR-02** | **B-01** | **Hold Time Expiry (Khóa phòng ảo)** | Khách tạo QR cọc nhưng bỏ đi không thanh toán. | **Auto-Expire Cron Job / Supabase Edge Function**: Tự động chuyển đơn sang `EXPIRED` sau 15 phút (theo Bank QR Timeout) và nhả kho phòng. | Không cần thao tác thủ công. Hệ thống tự động nhả kho phòng. |
| **BR-03** | **B-02** | **Manual OTA Sync Delay (Đụng phòng Agoda)** | Khách đặt Agoda lúc 2h sáng, Lễ tân ngủ chưa khóa CMS. | Tạo **Nút Khóa Phòng Khẩn Cấp (Emergency Lock)** trên CMS di động + giữ 1-2 phòng đệm (Buffer). | Website chính thức có quyền ưu tiên. Lễ tân liên hệ Agoda xin xếp phòng tương đương. |
| **BR-04** | **C-01** | **Fake Payment Callback (Giả mạo Webhook)** | Kẻ xấu gọi giả lập API `/api/webhooks/payment` báo "Đã cọc". | Bắt buộc kiểm tra **Chữ ký điện tử HMAC-SHA256** từ cổng thanh toán và đối soát `transaction_id`. | Lễ tân kiểm tra biến động số dư ngân hàng doanh nghiệp trước khi giao phòng. |
| **BR-05** | **O-01** | **Unauthorized Privilege Escalation (Vượt quyền)** | Lễ tân cố tình gọi API chỉnh sửa giá phòng gốc hoặc xóa tài khoản. | **JWT Access Token & Refresh Token + Next.js Middleware Guard**: Kiểm tra cờ `role` trên server-side. Trả về `403 Forbidden` nếu không phải `SUPERADMIN`. | Lễ tân chỉ được cấp tài khoản role `USER`. |
| **BR-06** | **B-04** | **No-Show Revenue & Room Loss (Khách vắng mặt)** | Khách cọc rồi biến mất không đến, phòng bị giữ ảo qua đêm. | **Cron Job Auto-NoShow**: Tự động chuyển đơn thành `NO_SHOW` và nhả kho phòng lúc 18h00 ngày Check-in nếu không có biến động. | Lễ tân kiểm tra danh sách khách chưa check-in lúc 17h30 để gọi điện nhắc khách. |
| **PR-01** | **P-03** | **Surcharge & Discount Calculation Bug** | Công thức tính % giảm giá trúng cả khoản phụ thu làm thất thoát tiền. | Chuẩn hóa công thức Server-side: **`Total = (BaseRate - Discount) + Surcharges`**. % Discount chỉ áp trên Giá phòng gốc. | Bảng phân rã chi tiết tiền hiển thị rõ trên Email xác nhận và `/lookup`. |
| **PR-02** | **P-06** | **Reschedule Audit Trail Bug** | Khách đổi ngày nhưng tiền chênh lệch không được lưu vết rõ ràng. | Viết API `/api/bookings/reschedule` tính lại tiền chênh lệch và tự động ghi log vào `booking_audit_logs`. | Lễ tân tra cứu lịch sử đổi ngày trực tiếp trên màn hình chi tiết đơn hàng CMS. |
| **PR-03** | **P-07** | **Min-Nights Holiday Bypass (Bỏ qua số đêm Lễ)** | Khách cố tình chọn 1 đêm vào dịp Lễ Tết làm mất doanh thu ngày Lễ. | **Server-side Validation Guard**: Kiểm tra `check_in_date` & `check_out_date` với `min_nights_holiday`. Trả về lỗi 400 Bad Request nếu phạm quy. | Màn hình đặt phòng hiển thị thông báo "Dịp Lễ yêu cầu đặt tối thiểu X đêm". |
